import React from 'react'

const ContactUS = () => {
  return (
    <div className='d-flex justify-content-center' style={{ height: "87.6vh" }}>ContactUS</div>
  )
}

export default ContactUS