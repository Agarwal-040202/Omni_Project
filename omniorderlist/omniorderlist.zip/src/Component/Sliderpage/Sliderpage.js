import React from 'react'
import "../Sliderpage/sliderpage.css"
const Sliderpage = () => {
    return (
        <div style={{ border: "2px solid black" }}>
            {/* <div style={{width:"100%",height:"100vh"}}> */}

            {/* <video autoPlay loop controls style={{ width: "100%", height: "100%" }} >
                <source src="./Omniscrew.mp4" type="video/mp4" />
            </video> */}
            {/* </div> */}


        </div>

    )
}

export default Sliderpage