import React from 'react'

const OrderByShopkeeper = () => {
  return (
    <div className='d-flex justify-content-center' style={{ height: "87.6vh" }}>OrderByShopkeeper</div>
  )
}

export default OrderByShopkeeper