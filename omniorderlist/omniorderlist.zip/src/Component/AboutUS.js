import React from 'react'

const AboutUS = () => {
  return (
    <div className='d-flex justify-content-center' style={{ height: "87.6vh" }}>AboutUS</div>
  )
}

export default AboutUS