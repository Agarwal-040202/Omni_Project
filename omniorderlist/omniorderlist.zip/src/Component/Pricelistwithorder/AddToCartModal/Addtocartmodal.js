import React from 'react'

const Addtocartmodal = () => {
  return (
    <div>Addtocartmodal</div>
  )
}

export default Addtocartmodal